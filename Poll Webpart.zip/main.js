var PollQuestionslistName = 'PollQuestions';
var PollLogslistName = 'PollLogs';

var appPollResults = angular.module('ng-app-polls', []);

//Controller
appPollResults.controller('pollSubmitCtrl', function ($scope, pollResultsService) {
    $scope.poll = [];

    $scope.getUserDetails = function (pollData) {
        pollResultsService.getUserDetailById(pollData.Question.Id)
        .then(
        function (isSubmitted) {

            pollData.result = isSubmitted;
            $scope.poll = pollData;
        }
        );
    }

    $scope.getPollsData = function () {
        pollResultsService.getPollDetails(PollQuestionslistName)
        .then(
        function (pollData) {
            $scope.getUserDetails(pollData);
        }
        );
    }

    $scope.pollSubmit = function () {

        pollResultsService.getLoginName()
        .then(
        function (userLogin) {
            pollResultsService.setUserDetailById($scope.poll.Question.Id, $scope.poll.selectedAnswer, userLogin)
            .then(
            function (success) {
                if (success) {
                    pollResultsService.getItemById($scope.poll.Question.Id)
                    .then(
                    function (data1, pollData) {
                        var selectedAns = $scope.poll.selectedAnswer;
                        pollResultsService.setPollDetails(selectedAns, data1, pollData)
                        .then(
                        function (success) {
                            if (success) {
                                pollResultsService.getPollDetails(PollQuestionslistName)
                                .then(
                                function (pollData) {
                                    pollData.result = true;
                                    $scope.poll = pollData;
                                });
                            }
                        }
                        );
                    }
                    );
                } else {
                    alert('unknown error occured');
                }
            });
        });
    }

    $scope.getPollsData();

    $scope.selectedIndex = null;
    $scope.selectedAnswer = function (index) {
        $scope.selectedIndex = index;
    }

});

//Services
appPollResults.service(
        'pollResultsService',
        function ($http, $q) {
            return ({
                getPollDetails: getPollDetails,
                setPollDetails: setPollDetails,
                setUserDetailById: setUserDetailById,
                getUserDetailById: getUserDetailById,
                getItemById: getItemById,
                getLoginName: getLoginName
            });

            //Get the Poll Question and Answers
            function getPollDetails() {

                var fullUrl = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getbytitle('" + PollQuestionslistName + "')/Items?$Select=";
                fullUrl += 'ID,Title,Answer1,Answer2,Answer3,Answer4,CountAnswer1,CountAnswer2,CountAnswer3,CountAnswer4,TotalCount,Symbol/Value&$expand=Symbol&$orderby=ID desc&$filter=Active eq 1&$Top=1';

                var request = $http({
                    method: 'Get',
                    url: fullUrl,
                    headers: { "accept": "application/json;odata=verbose" }
                });

                return (request.then(successGetPollDetails, handleError));
            }

            //Success Poll Details
            function successGetPollDetails(data) {
                var pollData;
                if (data.data.d.results.length > 0) {
                    var result = data.data.d.results[0];
                    var percent1 = ((result.CountAnswer1 / result.TotalCount) * 100).toFixed(0) + '%';
                    var percent2 = ((result.CountAnswer2 / result.TotalCount) * 100).toFixed(0) + '%';
                    var percent3 = ((result.CountAnswer3 / result.TotalCount) * 100).toFixed(0) + '%';
                    var percent4 = ((result.CountAnswer4 / result.TotalCount) * 100).toFixed(0) + '%';
                    var percent5 = ((result.CountAnswer5 / result.TotalCount) * 100).toFixed(0) + '%';

                    pollData = angular.fromJson({
                        "hasData": true,
                        "result": false,
                        "Question": {
                            "Id": result.ID,
                            "Text": result.Title,
                            "Symbol": result.Symbol.Value,
                            "Total": result.TotalCount
                        },
                        "Answers": [{
                            "Id": 1,
                            "Text": result.Answer1,
                            "Count": result.CountAnswer1,
                            "Percent": percent1
                        }, {
                            "Id": 2,
                            "Text": result.Answer2,
                            "Count": result.CountAnswer2,
                            "Percent": percent2
                        }]
                    });

                    if (result.Answer3) {
                        var obj = {};
                        obj["Id"] = 3;
                        obj["Text"] = result.Answer3;
                        obj["Count"] = result.CountAnswer3;
                        obj["Percent"] = percent3;
                        pollData.Answers.push(obj);
                    }
                    if (result.Answer4) {
                        var obj = {};
                        obj["Id"] = 4;
                        obj["Text"] = result.Answer4;
                        obj["Count"] = result.CountAnswer4;
                        obj["Percent"] = percent4;
                        pollData.Answers.push(obj);
                    }
                    if (result.Answer5) {
                        var obj = {};
                        obj["Id"] = 5;
                        obj["Text"] = result.Answer5;
                        obj["Count"] = result.CountAnswer5;
                        obj["Percent"] = percent5;
                        pollData.Answers.push(obj);

                    }
                } else {
                    pollData = angular.fromJson({
                        "hasData": false,
                        "result": false,
                        "Question": {
                            "Id": 0,
                            "Text": "",
                            "Symbol": "",
                            "Total": 0
                        },
                        "Answers": [{}]
                    });
                }
                return (pollData);
            }

            //Set the Poll Details
            function setPollDetails(selectedAnsId, data1) {

                var fullUrl = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getbytitle('" + PollQuestionslistName + "')/items";
                var itemType = "SP.Data." + PollQuestionslistName + "ListItem";

                var selAns = 'CountAnswer' + selectedAnsId;
                var value = '';
                var cat = {
                    '__metadata': { "type": itemType }
                };

                if (selectedAnsId == '1') {
                    value = data1.data.d.CountAnswer1;
                } else if (selectedAnsId == '2') {
                    value = data1.data.d.CountAnswer2;
                } else if (selectedAnsId == '3') {
                    value = data1.data.d.CountAnswer3;
                } else {
                    value = data1.data.d.CountAnswer4;
                }

                cat[selAns] = value + 1;
                cat['TotalCount'] = data1.data.d.TotalCount + 1;

                var request = $http({
                    url: data1.data.d.__metadata.uri,
                    method: "POST",
                    data: JSON.stringify(cat),
                    headers: {
                        "Accept": "application/json;odata=verbose",
                        "X-RequestDigest": $("#__REQUESTDIGEST").val(),
                        "X-HTTP-Method": "MERGE",
                        "Content-Type": "application/json;odata=verbose",
                        "If-Match": data1.data.d.__metadata.etag
                    }
                });


                return (request.then(successSetPollDetails, handleError));
            }

            function successSetPollDetails(data) {

                return true;
            }

            //Set the Poll Details
            function setUserDetailById(QuestionId, selectedAnswer, userLogin) {

                var fullUrl = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getbytitle('" + PollLogslistName + "')/items";
                var itemType = "SP.Data." + PollLogslistName + "ListItem";

                var cat = {
                    "__metadata": { "type": itemType },
                    "Title": userLogin.UserName,
                    "loginid": userLogin.UserId,
                    "userid": _spPageContextInfo.userId,
                    "SelectedAnswer":String(selectedAnswer),
                    "QuestionId": String(QuestionId)
                };

                var request = $http({
                    url: fullUrl,
                    method: "POST",
                    data: JSON.stringify(cat),
                    headers: {
                        "Accept": "application/json;odata=verbose",
                        "X-RequestDigest": $("#__REQUESTDIGEST").val(),
                        "Content-Type": "application/json;odata=verbose"
                    }
                });

                return (request.then(successSetUserDetailById, handleError));
            }

            function successSetUserDetailById(data) {
                return true;
            }

            function getUserDetailById(itemID) {

                var fullUrl = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getbytitle('" + PollLogslistName + "')/Items?$Select=";
                fullUrl += "Title,QuestionId&$filter=userid eq '" + _spPageContextInfo.userId + "' and QuestionId eq '" + itemID + "'&$top=1";

                var request = $http({
                    method: 'Get',
                    url: fullUrl,
                    headers: { "accept": "application/json;odata=verbose" }
                });

                return (request.then(successGetUserDetailById, handleError));
            }

            function successGetUserDetailById(data) {
                if (data.data.d.results.length > 0) {
                    return true;
                } else {
                    return false;
                }

            }

            function getItemById(itemID) {

                var fullUrl = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getbytitle('" + PollQuestionslistName + "')/Items('" + itemID + "')";

                var request = $http({
                    url: fullUrl,
                    Method: "GET",
                    headers: { "accept": "application/json;odata=verbose" },
                });

                return (request.then(successGetItemById, handleError));
            }

            function successGetItemById(data) {
                return data;
            }

            function getLoginName() {
                var userid = _spPageContextInfo.userId;
                var fullUrl = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + userid + ")";

                var request = $http({
                    url: fullUrl,
                    contentType: "application/json;odata=verbose",
                    Method: "GET",
                    headers: { "accept": "application/json;odata=verbose" },
                });

                return (request.then(successGetLoginName, handleError));
            }

            function successGetLoginName(data) {
                var lname = data.data.d.LoginName;
                lname = lname.split("|")[1];
                var userLogin = {
                    "UserName": data.data.d.Title,
                    "UserId": lname,
                    "Email": data.data.d.Email
                }
                return userLogin;
            }

            //Handle Error
            function handleError(response) {

                if (
                    !angular.isObject(response.data) ||
                    !response.data.message
                    ) {
                    return ($q.reject("An unknown error occurred."));
                }
                // Otherwise, use expected error message.
                return ($q.reject(response.data.message));
            }
        }
);



